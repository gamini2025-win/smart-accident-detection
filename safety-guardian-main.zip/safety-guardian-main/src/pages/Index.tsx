import { useState } from "react";
import BottomNav from "@/components/BottomNav";
import HomeScreen from "@/components/screens/HomeScreen";
import AlertScreen from "@/components/screens/AlertScreen";
import MapScreen from "@/components/screens/MapScreen";
import ContactsScreen from "@/components/screens/ContactsScreen";
import SettingsScreen from "@/components/screens/SettingsScreen";

type Tab = "home" | "alert" | "map" | "contacts" | "settings";

const Index = () => {
  const [activeTab, setActiveTab] = useState<Tab>("home");

  const renderScreen = () => {
    switch (activeTab) {
      case "home": return <HomeScreen />;
      case "alert": return <AlertScreen />;
      case "map": return <MapScreen />;
      case "contacts": return <ContactsScreen />;
      case "settings": return <SettingsScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {renderScreen()}
      <BottomNav active={activeTab} onNavigate={setActiveTab} />
    </div>
  );
};

export default Index;
