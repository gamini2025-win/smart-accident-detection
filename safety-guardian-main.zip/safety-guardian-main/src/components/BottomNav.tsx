import { Home, AlertTriangle, Map, Users, Settings } from "lucide-react";

type Tab = "home" | "alert" | "map" | "contacts" | "settings";

interface BottomNavProps {
  active: Tab;
  onNavigate: (tab: Tab) => void;
}

const tabs: { id: Tab; icon: typeof Home; label: string }[] = [
  { id: "home", icon: Home, label: "Home" },
  { id: "alert", icon: AlertTriangle, label: "Alert" },
  { id: "map", icon: Map, label: "Map" },
  { id: "contacts", icon: Users, label: "Contacts" },
  { id: "settings", icon: Settings, label: "Settings" },
];

const BottomNav = ({ active, onNavigate }: BottomNavProps) => (
  <nav className="fixed bottom-0 left-0 right-0 z-50 glass-card rounded-none border-t border-border/50 border-x-0 border-b-0 px-2 pb-6 pt-2">
    <div className="flex items-center justify-around max-w-md mx-auto">
      {tabs.map(({ id, icon: Icon, label }) => {
        const isActive = active === id;
        const isAlert = id === "alert";
        return (
          <button
            key={id}
            onClick={() => onNavigate(id)}
            className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all duration-200 ${
              isActive
                ? isAlert
                  ? "text-emergency"
                  : "text-foreground"
                : "text-muted-foreground hover:text-foreground/70"
            }`}
          >
            <div className={`p-1.5 rounded-xl transition-all ${isActive ? (isAlert ? "bg-emergency/15" : "bg-accent") : ""}`}>
              <Icon size={20} strokeWidth={isActive ? 2.5 : 1.8} />
            </div>
            <span className="text-[10px] font-medium">{label}</span>
          </button>
        );
      })}
    </div>
  </nav>
);

export default BottomNav;
