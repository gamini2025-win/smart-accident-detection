import { MapPin, Navigation, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";

const MapScreen = () => {
  const lat = 28.6139;
  const lng = 77.209;

  return (
    <div className="px-4 pt-12 pb-28 space-y-5 max-w-md mx-auto">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Accident Map</h1>
        <p className="text-xs text-muted-foreground">Last detected incident location</p>
      </div>

      {/* Map placeholder */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="relative rounded-2xl overflow-hidden h-72 bg-muted/60 border border-border/50"
      >
        {/* Grid to simulate map */}
        <div className="absolute inset-0 opacity-[0.06]">
          {[...Array(16)].map((_, i) => (
            <div key={`h-${i}`} className="absolute border-t border-foreground" style={{ top: `${(i + 1) * 6.25}%`, width: '100%' }} />
          ))}
          {[...Array(20)].map((_, i) => (
            <div key={`v-${i}`} className="absolute border-l border-foreground h-full" style={{ left: `${(i + 1) * 5}%` }} />
          ))}
        </div>

        {/* Marker */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative">
            <motion.div
              animate={{ scale: [1, 2, 1], opacity: [0.4, 0, 0.4] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 w-12 h-12 -translate-x-1/2 -translate-y-1/2 rounded-full bg-emergency/40"
              style={{ left: '50%', top: '50%' }}
            />
            <motion.div
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <MapPin size={36} className="text-emergency drop-shadow-lg" fill="hsl(var(--emergency))" />
            </motion.div>
          </div>
        </div>

        {/* Road lines */}
        <div className="absolute top-[45%] left-0 right-0 h-px bg-foreground/10" />
        <div className="absolute top-0 bottom-0 left-[48%] w-px bg-foreground/10" />
      </motion.div>

      {/* Location info */}
      <div className="glass-card p-4 space-y-3">
        <h3 className="text-sm font-semibold">Incident Details</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-muted/50 rounded-lg p-3">
            <span className="text-[10px] text-muted-foreground block">Latitude</span>
            <span className="text-sm font-mono font-medium">{lat}° N</span>
          </div>
          <div className="bg-muted/50 rounded-lg p-3">
            <span className="text-[10px] text-muted-foreground block">Longitude</span>
            <span className="text-sm font-mono font-medium">{lng}° E</span>
          </div>
        </div>
        <div className="bg-muted/50 rounded-lg p-3">
          <span className="text-[10px] text-muted-foreground block">Address</span>
          <span className="text-sm font-medium">Connaught Place, New Delhi, India</span>
        </div>
        <div className="bg-muted/50 rounded-lg p-3">
          <span className="text-[10px] text-muted-foreground block">Detected At</span>
          <span className="text-sm font-mono font-medium">2025-03-28 14:32:07 IST</span>
        </div>
      </div>

      {/* Navigate button */}
      <a
        href={`https://www.google.com/maps?q=${lat},${lng}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors"
      >
        <Navigation size={16} />
        Navigate to Location
        <ExternalLink size={12} />
      </a>
    </div>
  );
};

export default MapScreen;
