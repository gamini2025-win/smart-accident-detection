import { ShieldCheck, Bluetooth, Usb, MapPin, Wifi, WifiOff, Activity } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";

const HomeScreen = () => {
  const [connected, setConnected] = useState(false);

  return (
    <div className="px-4 pt-12 pb-28 space-y-5 max-w-md mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">SafeGuard</h1>
          <p className="text-xs text-muted-foreground">Accident Detection System</p>
        </div>
        <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${
          connected ? "bg-safe/15 text-safe" : "bg-emergency/15 text-emergency"
        }`}>
          {connected ? <Wifi size={12} /> : <WifiOff size={12} />}
          {connected ? "Connected" : "Disconnected"}
        </div>
      </div>

      {/* Vehicle Status */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card overflow-hidden"
      >
        {/* Top gradient bar */}
        <div className="h-1 w-full bg-gradient-to-r from-safe via-secondary to-accent" />
        
        <div className="p-5 flex items-center gap-4">
          {/* Animated ring indicator */}
          <div className="relative flex-shrink-0">
            <svg width="64" height="64" viewBox="0 0 64 64">
              <circle cx="32" cy="32" r="28" fill="none" stroke="hsl(var(--muted))" strokeWidth="3" />
              <motion.circle
                cx="32" cy="32" r="28"
                fill="none"
                stroke="hsl(var(--safe))"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray={175.9}
                initial={{ strokeDashoffset: 175.9 }}
                animate={{ strokeDashoffset: 0 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                transform="rotate(-90 32 32)"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <ShieldCheck size={22} className="text-safe" />
            </div>
          </div>

          {/* Status text */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-safe">Vehicle Safe</h2>
              <motion.span
                animate={{ opacity: [1, 0.4, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-2 h-2 rounded-full bg-safe inline-block"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">All sensors normal</p>
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 border-t border-border/40">
          <div className="px-4 py-3 text-center border-r border-border/40">
            <span className="text-[10px] text-muted-foreground block">G-Force</span>
            <span className="text-sm font-mono font-semibold">0.2g</span>
          </div>
          <div className="px-4 py-3 text-center border-r border-border/40">
            <span className="text-[10px] text-muted-foreground block">Speed</span>
            <span className="text-sm font-mono font-semibold">45 <span className="text-[10px] text-muted-foreground">km/h</span></span>
          </div>
          <div className="px-4 py-3 text-center">
            <span className="text-[10px] text-muted-foreground block">Status</span>
            <span className="text-xs font-semibold text-safe">Normal</span>
          </div>
        </div>
      </motion.div>

      {/* Connect */}
      <div className="glass-card p-4 space-y-3">
        <h3 className="text-sm font-semibold">Device Connection</h3>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setConnected(!connected)}
            className="flex items-center gap-2 px-4 py-3 rounded-xl bg-secondary/15 hover:bg-secondary/25 transition-colors text-sm font-medium text-secondary"
          >
            <Bluetooth size={16} />
            Bluetooth
          </button>
          <button
            onClick={() => setConnected(!connected)}
            className="flex items-center gap-2 px-4 py-3 rounded-xl bg-secondary/15 hover:bg-secondary/25 transition-colors text-sm font-medium text-secondary"
          >
            <Usb size={16} />
            USB OTG
          </button>
        </div>
        {connected && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-2 font-mono">
            Arduino Nano → Serial: ACCIDENT,28.6139,77.2090
          </motion.div>
        )}
      </div>

      {/* Location */}
      <div className="glass-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <MapPin size={14} className="text-primary" /> Last Known Location
          </h3>
          <span className="text-[10px] text-muted-foreground">Updated 2s ago</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-muted/50 rounded-lg p-3">
            <span className="text-[10px] text-muted-foreground block">Latitude</span>
            <span className="text-sm font-mono font-medium">28.6139° N</span>
          </div>
          <div className="bg-muted/50 rounded-lg p-3">
            <span className="text-[10px] text-muted-foreground block">Longitude</span>
            <span className="text-sm font-mono font-medium">77.2090° E</span>
          </div>
        </div>
        {/* Map preview placeholder */}
        <div className="relative rounded-xl overflow-hidden h-32 bg-muted/80">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <MapPin size={24} className="text-primary mx-auto mb-1" />
              <span className="text-xs text-muted-foreground">New Delhi, India</span>
            </div>
          </div>
          {/* Grid lines to simulate map */}
          <div className="absolute inset-0 opacity-10">
            {[...Array(8)].map((_, i) => (
              <div key={`h-${i}`} className="absolute border-t border-foreground" style={{ top: `${(i + 1) * 12.5}%`, width: '100%' }} />
            ))}
            {[...Array(12)].map((_, i) => (
              <div key={`v-${i}`} className="absolute border-l border-foreground h-full" style={{ left: `${(i + 1) * 8.3}%` }} />
            ))}
          </div>
        </div>
      </div>

      {/* Arduino Data Preview */}
      <div className="glass-card p-4">
        <h3 className="text-sm font-semibold mb-2">Live Sensor Data</h3>
        <div className="bg-muted/50 rounded-lg p-3 font-mono text-xs space-y-1">
          <div className="flex justify-between"><span className="text-muted-foreground">Accelerometer X</span><span>0.12g</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Accelerometer Y</span><span>0.08g</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Accelerometer Z</span><span>0.98g</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Impact Threshold</span><span className="text-safe">Normal</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">GPS Fix</span><span className="text-safe">3D Fix</span></div>
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
