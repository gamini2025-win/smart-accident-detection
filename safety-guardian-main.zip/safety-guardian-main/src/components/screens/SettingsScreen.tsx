import { Bell, Vibrate, MessageSquare, Timer, MapPin, Shield, Info } from "lucide-react";
import { useState } from "react";

const SettingsScreen = () => {
  const [soundAlert, setSoundAlert] = useState(true);
  const [vibration, setVibration] = useState(true);
  const [autoSms, setAutoSms] = useState(true);
  const [countdownDuration, setCountdownDuration] = useState(10);

  const Toggle = ({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) => (
    <button
      onClick={() => onChange(!value)}
      className={`w-11 h-6 rounded-full relative transition-colors ${value ? "bg-safe" : "bg-muted"}`}
    >
      <div className={`absolute top-1 w-4 h-4 rounded-full transition-all ${value ? "left-6 bg-safe-foreground" : "left-1 bg-muted-foreground"}`} />
    </button>
  );

  return (
    <div className="px-4 pt-12 pb-28 space-y-5 max-w-md mx-auto">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Settings</h1>
        <p className="text-xs text-muted-foreground">Configure alert preferences</p>
      </div>

      {/* Alert Settings */}
      <div className="glass-card p-4 space-y-0.5">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Alert Preferences</h3>
        
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center">
              <Bell size={16} className="text-primary" />
            </div>
            <div>
              <span className="text-sm font-medium">Sound Alert</span>
              <p className="text-[10px] text-muted-foreground">Play siren on accident detection</p>
            </div>
          </div>
          <Toggle value={soundAlert} onChange={setSoundAlert} />
        </div>

        <div className="border-t border-border/30" />

        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center">
              <Vibrate size={16} className="text-primary" />
            </div>
            <div>
              <span className="text-sm font-medium">Vibration</span>
              <p className="text-[10px] text-muted-foreground">Vibrate on emergency alerts</p>
            </div>
          </div>
          <Toggle value={vibration} onChange={setVibration} />
        </div>

        <div className="border-t border-border/30" />

        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center">
              <MessageSquare size={16} className="text-primary" />
            </div>
            <div>
              <span className="text-sm font-medium">Auto SMS</span>
              <p className="text-[10px] text-muted-foreground">Automatically send SMS on accident</p>
            </div>
          </div>
          <Toggle value={autoSms} onChange={setAutoSms} />
        </div>
      </div>

      {/* Countdown */}
      <div className="glass-card p-4">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Countdown Timer</h3>
        <div className="flex items-center gap-3">
          <Timer size={16} className="text-primary" />
          <span className="text-sm font-medium flex-1">Duration before alert</span>
          <span className="text-sm font-mono font-bold text-primary">{countdownDuration}s</span>
        </div>
        <input
          type="range"
          min={5}
          max={30}
          value={countdownDuration}
          onChange={e => setCountdownDuration(Number(e.target.value))}
          className="w-full mt-3 accent-primary h-1"
        />
        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
          <span>5s</span><span>30s</span>
        </div>
      </div>

      {/* Permissions */}
      <div className="glass-card p-4 space-y-0.5">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Permissions</h3>
        
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <MapPin size={16} className="text-safe" />
            <span className="text-sm">Location Access</span>
          </div>
          <span className="text-xs text-safe font-medium px-2 py-1 rounded-full bg-safe/15">Granted</span>
        </div>

        <div className="border-t border-border/30" />

        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <MessageSquare size={16} className="text-safe" />
            <span className="text-sm">SMS Permission</span>
          </div>
          <span className="text-xs text-safe font-medium px-2 py-1 rounded-full bg-safe/15">Granted</span>
        </div>

        <div className="border-t border-border/30" />

        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <Shield size={16} className="text-safe" />
            <span className="text-sm">Background Activity</span>
          </div>
          <span className="text-xs text-safe font-medium px-2 py-1 rounded-full bg-safe/15">Granted</span>
        </div>
      </div>

      {/* Version */}
      <div className="text-center text-xs text-muted-foreground space-y-1 pt-4">
        <div className="flex items-center justify-center gap-1"><Info size={12} /> SafeGuard v1.0.0</div>
        <div>Arduino Accident Detection System</div>
      </div>
    </div>
  );
};

export default SettingsScreen;
