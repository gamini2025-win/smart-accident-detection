import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, ShieldCheck, Phone, MessageSquare } from "lucide-react";

const AlertScreen = () => {
  const [accidentDetected, setAccidentDetected] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const [alertSent, setAlertSent] = useState(false);

  useEffect(() => {
    if (!accidentDetected || alertSent) return;
    if (countdown <= 0) {
      setAlertSent(true);
      return;
    }
    const timer = setTimeout(() => setCountdown(c => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [accidentDetected, countdown, alertSent]);

  const cancelAlert = useCallback(() => {
    setAccidentDetected(false);
    setCountdown(10);
    setAlertSent(false);
  }, []);

  const simulateAccident = () => {
    setAccidentDetected(true);
    setCountdown(10);
    setAlertSent(false);
  };

  if (!accidentDetected) {
    return (
      <div className="px-4 pt-12 pb-28 max-w-md mx-auto flex flex-col items-center justify-center min-h-[80vh]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6"
        >
          <div className="w-24 h-24 rounded-full bg-safe/10 flex items-center justify-center mx-auto">
            <ShieldCheck size={48} className="text-safe" />
          </div>
          <div>
            <h2 className="text-xl font-bold">System Active</h2>
            <p className="text-sm text-muted-foreground mt-1">Monitoring for accidents in real-time</p>
          </div>
          <button
            onClick={simulateAccident}
            className="px-6 py-3 rounded-xl bg-emergency/15 text-emergency font-semibold text-sm hover:bg-emergency/25 transition-colors"
          >
            <AlertTriangle size={16} className="inline mr-2" />
            Simulate Accident
          </button>
        </motion.div>
      </div>
    );
  }

  if (alertSent) {
    return (
      <div className="px-4 pt-12 pb-28 max-w-md mx-auto flex flex-col items-center justify-center min-h-[80vh]">
        <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="text-center space-y-6">
          <div className="w-24 h-24 rounded-full bg-emergency/20 emergency-glow flex items-center justify-center mx-auto pulse-emergency">
            <Phone size={40} className="text-emergency" />
          </div>
          <h2 className="text-2xl font-bold text-emergency">Alerts Sent!</h2>
          <div className="glass-card p-4 text-left space-y-2 text-sm">
            <div className="flex items-center gap-2"><MessageSquare size={14} className="text-safe" /> SMS sent to Amit Kumar</div>
            <div className="flex items-center gap-2"><MessageSquare size={14} className="text-safe" /> SMS sent to Priya Sharma</div>
            <div className="flex items-center gap-2"><Phone size={14} className="text-safe" /> Emergency services notified</div>
            <div className="text-xs text-muted-foreground mt-2 font-mono">Location: 28.6139°N, 77.2090°E</div>
          </div>
          <button onClick={cancelAlert} className="px-8 py-3 rounded-xl bg-safe text-safe-foreground font-bold text-sm">
            Reset System
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-40 flex flex-col items-center justify-center flash-bg">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="text-center space-y-6 px-6 max-w-sm"
      >
        <motion.div
          animate={{ scale: [1, 1.15, 1], rotate: [0, -5, 5, 0] }}
          transition={{ duration: 0.6, repeat: Infinity }}
          className="w-28 h-28 rounded-full bg-emergency/30 emergency-glow flex items-center justify-center mx-auto"
        >
          <AlertTriangle size={56} className="text-emergency" />
        </motion.div>

        <div>
          <h1 className="text-3xl font-black text-emergency pulse-emergency tracking-tight">
            ACCIDENT DETECTED
          </h1>
          <p className="text-sm text-foreground/70 mt-2">Sending emergency alerts in</p>
        </div>

        <motion.div
          key={countdown}
          initial={{ scale: 1.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-7xl font-black text-emergency font-mono"
        >
          {countdown}
        </motion.div>

        <p className="text-xs text-muted-foreground">seconds</p>

        {/* Vibration bars */}
        <div className="flex items-center justify-center gap-1">
          {[...Array(7)].map((_, i) => (
            <motion.div
              key={i}
              animate={{ height: [8, 24 + Math.random() * 16, 8] }}
              transition={{ duration: 0.4, repeat: Infinity, delay: i * 0.08 }}
              className="w-1.5 bg-emergency rounded-full"
              style={{ height: 8 }}
            />
          ))}
        </div>

        <button
          onClick={cancelAlert}
          className="w-full py-4 rounded-2xl bg-safe text-safe-foreground font-black text-lg tracking-wide active:scale-95 transition-transform"
        >
          I'M SAFE
        </button>
        <p className="text-[10px] text-muted-foreground">Tap to cancel emergency alert</p>
      </motion.div>
    </div>
  );
};

export default AlertScreen;
