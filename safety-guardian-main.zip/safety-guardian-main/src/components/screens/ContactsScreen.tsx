import { useState } from "react";
import { Plus, Star, Trash2, Edit2, Phone, MessageSquare, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Contact {
  id: string;
  name: string;
  phone: string;
  isPrimary: boolean;
  autoSms: boolean;
}

const initialContacts: Contact[] = [
  { id: "1", name: "Amit Kumar", phone: "+91 98765 43210", isPrimary: true, autoSms: true },
  { id: "2", name: "Priya Sharma", phone: "+91 87654 32109", isPrimary: false, autoSms: true },
  { id: "3", name: "Emergency Services", phone: "112", isPrimary: false, autoSms: false },
];

const ContactsScreen = () => {
  const [contacts, setContacts] = useState<Contact[]>(initialContacts);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");

  const addContact = () => {
    if (!newName || !newPhone) return;
    setContacts([...contacts, { id: Date.now().toString(), name: newName, phone: newPhone, isPrimary: false, autoSms: true }]);
    setNewName("");
    setNewPhone("");
    setShowAdd(false);
  };

  const deleteContact = (id: string) => setContacts(contacts.filter(c => c.id !== id));

  const togglePrimary = (id: string) =>
    setContacts(contacts.map(c => ({ ...c, isPrimary: c.id === id })));

  const toggleAutoSms = (id: string) =>
    setContacts(contacts.map(c => c.id === id ? { ...c, autoSms: !c.autoSms } : c));

  return (
    <div className="px-4 pt-12 pb-28 space-y-5 max-w-md mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Emergency Contacts</h1>
          <p className="text-xs text-muted-foreground">{contacts.length} contacts configured</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center hover:bg-primary/25 transition-colors"
        >
          <Plus size={20} />
        </button>
      </div>

      {/* Add contact modal */}
      <AnimatePresence>
        {showAdd && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="glass-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold">Add Contact</h3>
              <button onClick={() => setShowAdd(false)}><X size={16} className="text-muted-foreground" /></button>
            </div>
            <input
              placeholder="Name"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-muted/50 text-sm outline-none focus:ring-1 focus:ring-primary placeholder:text-muted-foreground"
            />
            <input
              placeholder="Phone number"
              value={newPhone}
              onChange={e => setNewPhone(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-muted/50 text-sm outline-none focus:ring-1 focus:ring-primary placeholder:text-muted-foreground"
            />
            <button onClick={addContact} className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm">
              Add Contact
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Contacts list */}
      <div className="space-y-3">
        {contacts.map(contact => (
          <motion.div
            key={contact.id}
            layout
            className="glass-card p-4"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
                  contact.isPrimary ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
                }`}>
                  {contact.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold">{contact.name}</span>
                    {contact.isPrimary && <Star size={12} className="text-warning fill-warning" />}
                  </div>
                  <span className="text-xs text-muted-foreground font-mono">{contact.phone}</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => togglePrimary(contact.id)} className="p-2 rounded-lg hover:bg-accent transition-colors">
                  <Star size={14} className={contact.isPrimary ? "text-warning fill-warning" : "text-muted-foreground"} />
                </button>
                <button onClick={() => deleteContact(contact.id)} className="p-2 rounded-lg hover:bg-emergency/10 transition-colors">
                  <Trash2 size={14} className="text-muted-foreground hover:text-emergency" />
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <MessageSquare size={12} /> Auto SMS
              </span>
              <button
                onClick={() => toggleAutoSms(contact.id)}
                className={`w-10 h-5 rounded-full relative transition-colors ${contact.autoSms ? "bg-safe" : "bg-muted"}`}
              >
                <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-foreground transition-transform ${contact.autoSms ? "left-5.5 translate-x-0.5" : "left-0.5"}`} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ContactsScreen;
